# Preparar una publicación de Nova en GitHub

## Texto sugerido para la descripción del repositorio

> **Nova — asistente local para Windows con Ollama, voz opcional, Nova Desktop, widgets y acceso móvil por Tailscale. Incluye asistentes de configuración Lite/estándar/Premium, personalización local y un agente con permisos. Los modelos y las claves son responsabilidad de cada usuario y no se incluyen.**

## Texto sugerido para el README o la descripción larga

> Nova es un proyecto personal de código abierto en desarrollo. Se ejecuta como aplicación Electron en Windows y puede usar modelos locales de Ollama. El instalador de dependencias no descarga modelos ni usa claves del autor. Al primer inicio puedes elegir un perfil de rendimiento, personalizar el trato y la personalidad de Nova, y seguir u omitir el tutorial. Los datos personales quedan en el equipo del usuario.
>
> Para conversar necesitas Node.js, Ollama y un modelo local. Voz y procesamiento de audio requieren Python y las dependencias indicadas. Tailscale y ntfy son opcionales. Revisa los requisitos, límites de compatibilidad, seguridad y licencia antes de instalar o redistribuir.

## Pasos para crear el repositorio

1. Crea un repositorio vacío en GitHub y elige la licencia que quieras publicar. No se incluye una licencia por defecto en esta copia.
2. Descomprime la carpeta limpia de Nova en un directorio que usarás como repositorio.
3. Revisa el estado y los archivos ignorados:

```powershell
Set-Location 'C:\RUTA\Nova-GitHub-Update26'
git init -b main
git status --short
git status --ignored --short
```

4. Confirma que solo aparecen archivos de código y documentación. `.env`, bases de datos, contactos, logs, `voices`, modelos y archivos `nova-personalizacion.txt` no deben aparecer en el área de staging.
5. Si la revisión está limpia, publica:

```powershell
git add .
git status --short
git commit -m "Publicar Nova Update26"
git remote add origin https://github.com/TU-USUARIO/TU-REPOSITORIO.git
git push -u origin main
```

GitHub puede pedir autenticación o crear un token desde su propio flujo. No escribas un token en los comandos, archivos ni historial de PowerShell.

## Prerrequisitos y comandos para otras personas

Ejecuta en PowerShell si faltan herramientas:

```powershell
winget install --id OpenJS.NodeJS.LTS -e
winget install --id Python.Python.3.12 -e
winget install --id Git.Git -e
irm https://ollama.com/install.ps1 | iex
```

Cierra y vuelve a abrir el terminal; clona y prepara:

```powershell
git clone https://github.com/TU-USUARIO/TU-REPOSITORIO.git
Set-Location .\TU-REPOSITORIO
Copy-Item .env.example .env
npm ci
py -3.12 -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
ollama pull qwen2.5:3b
npm run build
npm run electron
```

Para elegir otro perfil, cambia la descarga por una sola de estas:

```powershell
ollama pull qwen2.5:3b
ollama pull qwen3:4b
ollama pull qwen3:8b
```

Instala Tailscale desde [su página oficial](https://tailscale.com/download/), inicia sesión con la misma cuenta en PC y teléfono, abre Nova → Móvil y activa HTTPS desde ese panel. Instala ntfy desde su tienda móvil y suscríbete al tema de la configuración. No publiques el tema ni lo uses para mensajes privados en `ntfy.sh`.

## Lista antes de publicar

- [ ] Leer `README.md` y corregir el enlace de repositorio si se copió desde una plantilla.
- [ ] Ejecutar `npm test` y `npm run build` en Windows limpio.
- [ ] Verificar el primer inicio, omisión del tutorial, perfiles y restauración de valores predeterminados.
- [ ] No subir `.env`, `jarvis.db`, `contacts.json`, `.txt` personal, voces, instaladores, backups ni datos de prueba.
- [ ] Añadir una licencia elegida y revisar licencias de dependencias/modelos.
- [ ] Probar una instalación desde cero en una cuenta de Windows separada antes de anunciarla.

## Descargo funcional

Los perfiles son preajustes de modelo en una misma aplicación. El perfil automático estima por RAM y cantidad de procesadores lógicos, no realiza benchmark y no garantiza que un modelo vaya fluido. Los controles de voz/música y el acceso móvil dependen de drivers, aplicaciones, Tailscale y permisos del PC. No describas como universal una función pendiente de prueba en otro equipo.
