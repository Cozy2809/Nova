# Configuración de Nova para una instalación limpia

## Asistente inicial

Al abrir por primera vez aparece un asistente de tres pantallas:

1. **Perfil de modelo:** Nova Lite (`qwen2.5:3b`), Nova (`qwen3:4b`), Nova Premium (`qwen3:8b`) o Analizar mi PC. El análisis mira RAM total y procesadores lógicos. No mide GPU ni velocidad real. Solo el perfil seleccionado determina el modelo recomendado; Nova no descarga modelos a escondidas. Usa el botón de descarga o Ajustes.
2. **Personalización y módulos:** nombre de trato, personalidad, longitud, voz, iniciar en Nova Desktop, biblioteca y avisos ntfy.
3. **Tutorial:** chat/voz, Nova Desktop, ntfy y Tailscale. El botón **Omitir tutorial** cierra el recorrido.

Los valores existentes en la base de datos se precargan. Completar el asistente añade `setupComplete`; no elimina memoria, historial ni otros ajustes.

## Valores predeterminados

En Ajustes → **DEJAR PREDETERMINADO** restablece las opciones editables de IA/voz y el modo de rendimiento. Conserva el texto del TXT personal y la configuración del tema ntfy. En Ajustes de Nova Desktop → Datos, **Dejar escritorio predeterminado** restablece tema, dock, barra y posiciones; no elimina aplicaciones, archivos, conversaciones ni memoria.

## Archivo de personalidad

El botón **ABRIR nova-personalizacion.txt** edita un archivo local del usuario dentro del directorio `userData` de Electron. El contenido se limita a 4.000 caracteres. Líneas que empiezan por `#` son comentarios. No añadas información privada o secretos. El archivo no forma parte del repositorio ni del paquete de Update26.

## ntfy

El tema se puede generar desde el asistente o escribir manualmente. En el móvil, instala ntfy y suscríbete al mismo tema. El envío automático está apagado de fábrica en `.env.example` y se puede activar expresamente. `ntfy.sh` usa temas públicos; un nombre aleatorio reduce adivinanzas, pero cualquiera que conozca el tema puede publicar/suscribirse según las reglas públicas del servicio. No envíes datos privados.

## Tailscale y HTTPS

Instala Tailscale en PC y móvil, inicia sesión en la misma tailnet y mantén Nova abierta. El panel Móvil detecta la dirección privada y tiene un control para HTTPS mediante `tailscale serve`. Serve solo comparte el puerto con la tailnet. Funnel es otro modo y puede ser público; Nova no lo activa. HTTPS requiere que la tailnet permita certificados y puede requerir aprobación en el panel DNS. Si el navegador del móvil no activa micrófono por HTTP, abre la URL HTTPS que genera Nova.

## Qué queda manual

- Instalar/abrir Ollama y descargar el modelo elegido.
- Instalar Tailscale y autenticar los dos dispositivos.
- Suscribirse al tema ntfy en el teléfono si se activan notificaciones.
- Verificar la reproducción multimedia: la disponibilidad de botones depende de la aplicación que entrega la sesión del sistema.
- El análisis de hardware no hace benchmarks y no estima el espacio libre del disco ni la VRAM.

## No incluido en una publicación pública

No añadas `.env`, `jarvis.db`, `contacts.json`, `*.log`, `voices/`, `node_modules/`, `dist/`, descargas de modelos, archivos de respaldo ni el TXT personal. `.gitignore` ya cubre las ubicaciones más habituales, pero revisa siempre `git status` y los archivos staged antes de publicar.
