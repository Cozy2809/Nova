module.exports = { ollama: require('./ollama') };
