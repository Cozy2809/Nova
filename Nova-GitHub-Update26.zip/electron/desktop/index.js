// Nova Desktop (proceso principal): ensambla servicios reales + herramientas del agente + IPC.
// createCore() no depende de Electron (se prueba con node --test); init() lo conecta a la app real.
'use strict';
const path = require('path');
const { createRegistry } = require('../agent/registry');
const { createAgent } = require('../agent/runner');
const { createAudit } = require('../agent/audit');
const { createFsGuard } = require('./fsGuard');
const { createFsService } = require('./fsService');
const { createSystem } = require('./system');

function createCore({ shell, execFile, getStats = () => null, getRoots, getPlaces = () => [], settings = () => ({}), env = process.env, emit = () => {}, auditFile = null, platform = process.platform, selfPid = process.pid, recentDir = null, os = require('os') }) {
  const guard = createFsGuard({ getRoots });
  const fsSvc = createFsService({ guard, trash: (p) => shell.trashItem(p), getPlaces });
  const system = createSystem({ execFile, platform, getStats, os, selfPid, shell, recentDir, guardSafe: (p) => guard.safe(p) });
  const registry = createRegistry();
  require('../agent/tools/fs').register(registry);
  require('../agent/tools/system').register(registry);
  const audit = createAudit(auditFile);
  const services = { fs: fsSvc, system, guard, shell };
  const agent = createAgent({ registry, audit, services, settings, env, emit });
  return { registry, agent, audit, services, guard };
}

let core = null, lastStats = null, widgetsWin = null;
const setStats = (m) => { lastStats = m; try { if (widgetsWin && !widgetsWin.isDestroyed()) widgetsWin.webContents.send('stats', m); } catch {} };

function init({ ipcMain, app, shell, getWin, mem, pcControl, execFile, BrowserWindow }) {
  const places = () => {
    const out = []; const add = (id, label, key) => { try { out.push({ id, label, path: app.getPath(key) }); } catch {} };
    add('desktop', 'Escritorio', 'desktop'); add('documents', 'Documentos', 'documents'); add('downloads', 'Descargas', 'downloads');
    add('pictures', 'Imágenes', 'pictures'); add('videos', 'Vídeos', 'videos'); add('music', 'Música', 'music');
    if (process.env.OneDrive) out.push({ id: 'onedrive', label: 'OneDrive', path: process.env.OneDrive });
    return out;
  };
  const send = (ev) => { for (const w of [getWin(), widgetsWin]) { try { if (w && !w.isDestroyed()) w.webContents.send('agent:event', ev); } catch {} } };
  core = createCore({
    shell, execFile, getStats: () => lastStats, getRoots: () => pcControl._roots(), getPlaces: places,
    settings: () => mem.getSettings(), env: process.env, emit: send, auditFile: path.join(app.getPath('userData'), 'agent-audit.jsonl'),
  });
  const createWidgetsWindow = () => {
    if (widgetsWin && !widgetsWin.isDestroyed()) return widgetsWin;
    if (!BrowserWindow || process.platform !== 'win32') throw new Error('Los widgets de escritorio están disponibles en Windows');
    const { screen } = require('electron'); const work = screen.getPrimaryDisplay().workArea;
    let prefs = {}; try { prefs = JSON.parse(mem.getSettings()['desk.prefs'] || '{}').nativeWidgets || {}; } catch {}
    const side = prefs.side === 'left' ? 'left' : 'right'; const size = ['compact', 'normal', 'wide'].includes(prefs.size) ? prefs.size : 'normal';
    const width = size === 'wide' ? 410 : size === 'compact' ? 286 : 318;
    const height = Math.max(440, Math.min(850, work.height - 24));
    widgetsWin = new BrowserWindow({
      x: side === 'left' ? work.x + 12 : work.x + Math.max(0, work.width - width - 12), y: work.y + 12, width, height,
      frame: false, transparent: true, backgroundColor: '#00000000', hasShadow: false,
      resizable: false, minimizable: false, maximizable: false, skipTaskbar: true,
      webPreferences: { preload: path.join(__dirname, '../preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: true },
    });
    widgetsWin.setIgnoreMouseEvents(true, { forward: true });
    widgetsWin.on('closed', () => { widgetsWin = null; });
    if (process.env.ELECTRON_DEV === '1') widgetsWin.loadURL('http://localhost:5173/widgets.html');
    else widgetsWin.loadFile(path.join(app.getAppPath(), 'dist', 'widgets.html'));
    return widgetsWin;
  };
  ipcMain.handle('desktop:widgets', (e, request = {}) => {
    const d = typeof request === 'string' ? { action: request } : (request || {}); const action = d.action || 'toggle';
    const main = getWin(); const allowed = e.sender === main?.webContents || e.sender === widgetsWin?.webContents;
    if (!allowed) return { error: 'Origen no permitido' };
    if (action === 'hide') {
      widgetsWin?.hide();
      if (getWin() && !getWin().isVisible()) app.quit();
      return { visible: false };
    }
    if (action === 'layout') {
      if (!widgetsWin || widgetsWin.isDestroyed()) return { error: 'Los widgets no están abiertos' };
      const side = d.side === 'left' ? 'left' : d.side === 'right' ? 'right' : null;
      const size = ['compact', 'normal', 'wide'].includes(d.size) ? d.size : null;
      if (!side || !size) return { error: 'Diseño no válido' };
      const { screen } = require('electron'); const work = screen.getDisplayMatching(widgetsWin.getBounds()).workArea;
      const width = size === 'wide' ? 410 : size === 'compact' ? 286 : 318; const bounds = widgetsWin.getBounds();
      widgetsWin.setBounds({ x: side === 'left' ? work.x + 12 : work.x + Math.max(0, work.width - width - 12), y: Math.min(bounds.y, work.y + work.height - 440), width, height: Math.min(bounds.height, work.height - 24) });
      return { visible: true };
    }
    if (action !== 'show' && action !== 'toggle') return { error: 'Acción no válida' };
    const w = createWidgetsWindow();
    if (action === 'toggle' && w.isVisible()) { w.hide(); return { visible: false }; }
    w.showInactive(); return { visible: true };
  });
  ipcMain.handle('desktop:widgets-input', (e, ignore) => {
    if (!widgetsWin || e.sender !== widgetsWin.webContents || widgetsWin.isDestroyed()) return { error: 'Origen no permitido' };
    widgetsWin.setIgnoreMouseEvents(ignore === true, { forward: true }); return { ok: true };
  });
  require('../agent/ipc').registerAgentIpc({
    ipcMain, getWin, agent: core.agent, registry: core.registry, audit: core.audit,
    isTrustedSender: (sender) => {
      const main = getWin();
      return sender === main?.webContents || sender === widgetsWin?.webContents;
    },
  });

  // Iconos de ventanas abiertas: solo de rutas que acaban de salir de la lista de ventanas del sistema
  const iconCache = new Map();
  ipcMain.handle('desktop:icon', async (e, d) => {
    const w = getWin(); if (!w || e.sender !== w.webContents) return { error: 'Origen no permitido' };
    const p = d && typeof d.path === 'string' ? d.path : '';
    if (!p || !core.lastWindowPaths || !core.lastWindowPaths.has(p.toLowerCase())) return { error: 'Icono no disponible' };
    if (iconCache.has(p)) return { icon: iconCache.get(p) };
    try { const img = await app.getFileIcon(p, { size: 'normal' }); const url = img.toDataURL(); iconCache.set(p, url); return { icon: url }; } catch { return { error: 'Sin icono' }; }
  });
  // Recuerda qué rutas de ejecutables salieron en la última consulta de ventanas (para validar los iconos)
  const orig = core.services.system.windows;
  core.services.system.windows = async () => { const r = await orig(); core.lastWindowPaths = new Set(r.map((x) => (x.path || '').toLowerCase()).filter(Boolean)); return r; };
  return core;
}
module.exports = { createCore, init, setStats, hasWidgets: () => !!widgetsWin && !widgetsWin.isDestroyed() && widgetsWin.isVisible() };
