# Nova Desktop — ventanas abiertas. Acciones: list | focus. Salida: JSON. SIN texto libre del usuario: solo un número de proceso.
# PENDIENTE DE VERIFICAR EN WINDOWS REAL (no se pudo ejecutar en el entorno de desarrollo).
param([string]$Action = 'list', [int]$ProcessId = 0)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type @"
using System; using System.Runtime.InteropServices;
public static class NovaWin {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
}
"@
if ($Action -eq 'list') {
  $rows = @(Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle } | ForEach-Object {
    $p = $null; try { $p = $_.Path } catch {}
    [pscustomobject]@{ pid = $_.Id; name = $_.ProcessName; title = $_.MainWindowTitle; path = $p }
  })
  ConvertTo-Json -Compress -InputObject $rows
} elseif ($Action -eq 'focus') {
  $proc = Get-Process -Id $ProcessId
  $h = $proc.MainWindowHandle
  if ($h -eq 0) { throw 'El proceso no tiene ventana' }
  if ([NovaWin]::IsIconic($h)) { [void][NovaWin]::ShowWindow($h, 9) }
  if ([NovaWin]::SetForegroundWindow($h)) { '{"ok":true}' } else { throw 'Windows no permitió traer la ventana al frente' }
} else { throw 'Acción desconocida' }
