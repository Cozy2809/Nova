import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles/hud.css';
import './styles/nova-window18.css';
createRoot(document.getElementById('root')).render(<App />);
