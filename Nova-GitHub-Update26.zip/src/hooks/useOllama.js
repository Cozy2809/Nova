// El streaming a Ollama ocurre en el proceso main (electron/providers/ollama.js); este alias mantiene la estructura del brief.
export { useAI as useOllama } from './useAI.js';
