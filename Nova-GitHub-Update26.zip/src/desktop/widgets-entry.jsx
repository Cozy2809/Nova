import React from 'react';
import { createRoot } from 'react-dom/client';
import WindowsWidgets from './WindowsWidgets.jsx';

createRoot(document.getElementById('root')).render(<WindowsWidgets />);
