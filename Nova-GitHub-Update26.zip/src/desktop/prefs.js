// Preferencias de Nova Desktop. Se guardan como JSON en la tabla `settings` existente (clave `desk.prefs`): sin migraciones.
import { useSyncExternalStore } from 'react';

export const DEFAULTS = {
  v: 2, theme: 'dark', wallpaper: 'aurora', accent: 'nova', accentHue: 192, startInDesktop: false,
  dock: { pos: 'bottom', size: 46, labels: false, pins: [] },
  bar: { cpu: true, ram: true, net: true, nova: true },
  widgets: { clock: { on: true, x: 28, y: 64 }, system: { on: true, x: 28, y: 430 }, music: { on: true, x: null, y: 64 }, quick: { on: false, x: null, y: 230 }, notes: { on: false, x: null, y: 540 }, net: { on: false, x: 28, y: 650 }, activity: { on: true, x: null, y: 390 } },
  nativeWidgets: { opacity: 58, side: 'right', size: 'normal' },
};
const clone = (o) => JSON.parse(JSON.stringify(o));
const merge = (base, over) => { if (!over || typeof over !== 'object') return base; const o = Array.isArray(base) ? over : { ...base }; if (Array.isArray(base)) return Array.isArray(over) ? over : base; for (const k of Object.keys(base)) { if (over[k] === undefined) continue; o[k] = base[k] && typeof base[k] === 'object' && !Array.isArray(base[k]) ? merge(base[k], over[k]) : over[k]; } return o; };

let prefs = clone(DEFAULTS), loaded = false, timer = null;
const subs = new Set(); const emit = () => subs.forEach((f) => f());
export const prefsLoaded = () => loaded;

export async function loadPrefs() {
  try {
    const s = await window.jarvis.getSettings(); const raw = s['desk.prefs'];
    if (raw) {
      const saved = JSON.parse(raw); const old = { clock: [28, 64], system: [28, 372], music: [null, 64], quick: [null, 220], notes: [null, 380], net: [28, 540], activity: [null, 330] };
      if ((Number(saved.v) || 1) < 2 && saved.widgets) {
        for (const [k, [x, y]] of Object.entries(old)) if (saved.widgets[k] && saved.widgets[k].x === x && saved.widgets[k].y === y) { saved.widgets[k].x = DEFAULTS.widgets[k].x; saved.widgets[k].y = DEFAULTS.widgets[k].y; }
        saved.v = 2;
      }
      prefs = merge(clone(DEFAULTS), saved);
    }
  } catch { prefs = clone(DEFAULTS); }
  loaded = true; emit(); return prefs;
}
export function setPrefs(patch) {
  prefs = merge(prefs, typeof patch === 'function' ? patch(prefs) : patch); emit();
  clearTimeout(timer); timer = setTimeout(() => { try { window.jarvis.setSettings({ 'desk.prefs': JSON.stringify(prefs) }); } catch {} }, 350);
}
export function resetPrefs() { prefs = clone(DEFAULTS); emit(); clearTimeout(timer); try { window.jarvis.setSettings({ 'desk.prefs': '' }); } catch {} } // vacío = valores por defecto (no se borra la fila)
export const usePrefs = () => useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => prefs);
// Cambios anidados cómodos
export const setDeep = (path, value) => setPrefs((p) => { const o = clone(p); let t = o; const ks = path.split('.'); ks.slice(0, -1).forEach((k) => { t = t[k]; }); t[ks[ks.length - 1]] = value; return o; });
