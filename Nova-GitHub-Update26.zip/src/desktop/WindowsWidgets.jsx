import React, { useEffect, useRef, useState } from 'react';
import { usePrefs, loadPrefs, setDeep } from './prefs.js';
import { Clock, Hardware, Network, Music, Notes } from './widgets/Widgets.jsx';
import { run, msgOf, startAgentEvents, useAgentStore } from './agent.js';
import Icon from './Icon.jsx';
import './desktop.css';

function ActivityPreview() {
  const { feed } = useAgentStore();
  const status = (s) => s === 'succeeded' ? 'Completado' : s === 'failed' ? 'Falló' : s === 'cancelled' ? 'Cancelado' : 'En curso';
  return <><h5><Icon n="pulse" s={14} />Actividad de Nova</h5>{feed.length ? feed.slice(0, 5).map((a) => <div className="nd-native-activity" key={a.id}><span className={a.state === 'succeeded' ? 'nd-ok' : a.state === 'failed' ? 'nd-err' : 'nd-mut'}>●</span><span>{a.summary || a.tool}</span><small>{status(a.state)}</small></div>) : <div className="nd-mut">Todavía no hay acciones recientes.</div>}</>;
}
function QuickAccess() {
  const prefs = usePrefs(); const [error, setError] = useState('');
  const items = prefs.dock.pins.filter((x) => x.type === 'app' || x.type === 'file').slice(0, 8);
  const open = async (item) => {
    try { setError(''); if (item.type === 'app') await run('apps.launch', { appId: item.appId }); else await run('fs.open', { path: item.path }); }
    catch (e) { setError(msgOf(e)); }
  };
  return <><h5><Icon n="pin" s={14} />Accesos rápidos</h5>{items.length ? <div className="nd-native-quick">{items.map((x) => <button className="nd-btn" key={x.appId || x.path} title={x.name} onClick={() => open(x)}>{x.name}</button>)}</div> : <div className="nd-mut">Fija aplicaciones o archivos en el dock de Nova para verlos aquí.</div>}{error && <div className="nd-err" role="alert">{error}</div>}</>;
}

const WIDGETS = { clock: Clock, system: Hardware, net: Network, music: Music, notes: Notes, activity: ActivityPreview, quick: QuickAccess };

export default function WindowsWidgets() {
  const prefs = usePrefs();
  const [ready, setReady] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const root = useRef(null);
  useEffect(() => {
    document.documentElement.classList.add('nova-widgets-page');
    startAgentEvents();
    loadPrefs().finally(() => setReady(true));
    return () => document.documentElement.classList.remove('nova-widgets-page');
  }, []);
  const opacity = Math.max(30, Math.min(90, Number(prefs.nativeWidgets.opacity) || 58));
  const transparency = 100 - opacity;
  const style = { ...(prefs.accent === 'fixed' ? { '--h': prefs.accentHue } : {}), '--native-alpha': opacity / 100 };
  const pass = (ignore) => window.jarvis.desktopWidgetsInput(ignore).catch(() => {});
  const setLayout = (key, value) => {
    setDeep('nativeWidgets.' + key, value);
    const next = { ...prefs.nativeWidgets, [key]: value };
    window.jarvis.desktopWidgets('layout', { side: next.side, size: next.size });
  };
  return <main ref={root} className="nd nd-native-widgets" data-theme={prefs.theme} style={style}>
    <header className="nd-native-head" onMouseEnter={() => pass(false)} onMouseLeave={() => pass(true)}>
      <span className="nd-native-title">NOVA · WIDGETS</span>
      <div className="nd-native-actions"><button aria-label="Personalizar widgets" title="Personalizar widgets" aria-expanded={settingsOpen} onClick={() => setSettingsOpen((v) => !v)}><Icon n="gear" s={14} /></button><button aria-label="Ocultar widgets" title="Ocultar widgets" onClick={() => window.jarvis.desktopWidgets('hide')}>×</button></div>
    </header>
    {settingsOpen && <section className="nd-native-settings" onMouseEnter={() => pass(false)} onMouseLeave={() => pass(true)}>
      <label>Transparencia <b>{transparency}%</b><input type="range" min="10" max="70" value={transparency} onChange={(e) => setDeep('nativeWidgets.opacity', 100 - Number(e.target.value))} /></label>
      <label>Posición <select value={prefs.nativeWidgets.side} onChange={(e) => setLayout('side', e.target.value)}><option value="right">Derecha</option><option value="left">Izquierda</option></select></label>
      <label>Tamaño <select value={prefs.nativeWidgets.size} onChange={(e) => setLayout('size', e.target.value)}><option value="compact">Compacto</option><option value="normal">Normal</option><option value="wide">Ancho</option></select></label>
      <small>El espacio transparente deja pasar clics a las aplicaciones que hay detrás.</small>
    </section>}
    {!ready ? <div className="nd-native-loading">Cargando widgets…</div> : <section className="nd-native-grid" data-size={prefs.nativeWidgets.size} onMouseEnter={() => pass(false)} onMouseLeave={() => pass(true)}>
      {Object.entries(WIDGETS).filter(([id]) => prefs.widgets[id]?.on).map(([id, Widget]) => <div className="nd-wg" key={id}><Widget /></div>)}
    </section>}
  </main>;
}
